<?php
require_once __DIR__ . '/../../middleware/role_spv.php';
require_once __DIR__ . '/../../config/database.php';
$pageTitle = 'Dashboard SPV';

$totalTrxToday = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c, IFNULL(SUM(total),0) s FROM transaksi WHERE DATE(tanggal)=CURDATE() AND status_pembayaran='PAID'"));
$totalStok     = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM stok"));
$draftLaporan  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM laporan WHERE status='DRAFT'"));
$recentTrx     = mysqli_query($conn,"SELECT t.*, u.nama FROM transaksi t JOIN users u ON t.id_kasir=u.id_user ORDER BY t.tanggal DESC LIMIT 7");
$stokRendah    = mysqli_query($conn,"SELECT * FROM stok WHERE jumlah < 10 ORDER BY jumlah ASC LIMIT 5");

include __DIR__ . '/../../includes/layout_start.php';
?>

<div class="row g-3 mb-4">
  <div class="col-sm-4">
    <div class="stat-card">
      <div class="s-ic mb-2" style="background:rgba(16,185,129,.1);color:#10b981"><i class="fa-solid fa-receipt"></i></div>
      <div style="font-size:24px;font-weight:800;color:#111827"><?= number_format($totalTrxToday['c']) ?></div>
      <div style="font-size:12px;color:#6b7280">Transaksi Hari Ini</div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="stat-card">
      <div class="s-ic mb-2" style="background:rgba(230,57,70,.1);color:#e63946"><i class="fa-solid fa-sack-dollar"></i></div>
      <div style="font-size:20px;font-weight:800;color:#111827">Rp <?= number_format($totalTrxToday['s'],0,',','.') ?></div>
      <div style="font-size:12px;color:#6b7280">Pendapatan Hari Ini</div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="stat-card">
      <div class="s-ic mb-2" style="background:rgba(245,158,11,.1);color:#f59e0b"><i class="fa-solid fa-file-alt"></i></div>
      <div style="font-size:24px;font-weight:800;color:#111827"><?= $draftLaporan['c'] ?></div>
      <div style="font-size:12px;color:#6b7280">Laporan Belum Final</div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card-box">
      <div class="c-head">
        <h5><i class="fa-solid fa-receipt me-2" style="color:#10b981"></i>Transaksi Terbaru</h5>
        <a href="transaksi.php" class="btn btn-sm btn-outline-secondary" style="font-size:11px">Lihat Semua</a>
      </div>
      <div class="c-body p-0">
        <table class="table table-hover mb-0">
          <thead><tr><th>No Struk</th><th>Kasir</th><th>Total</th><th>Status</th></tr></thead>
          <tbody>
          <?php while($t=mysqli_fetch_assoc($recentTrx)):
            $sc=['PAID'=>'sb-success','PENDING'=>'sb-warning','FAILED'=>'sb-danger'][$t['status_pembayaran']]??'';
          ?>
          <tr>
            <td><code style="font-size:11px"><?= htmlspecialchars($t['no_struk']) ?></code></td>
            <td><?= htmlspecialchars($t['nama']) ?></td>
            <td>Rp <?= number_format($t['total'],0,',','.') ?></td>
            <td><span class="rbadge <?=$sc?>"><?= $t['status_pembayaran'] ?></span></td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card-box">
      <div class="c-head">
        <h5><i class="fa-solid fa-triangle-exclamation me-2" style="color:#f59e0b"></i>Stok Hampir Habis</h5>
        <a href="stok.php" class="btn btn-sm btn-outline-secondary" style="font-size:11px">Lihat Stok</a>
      </div>
      <div class="c-body p-0">
        <table class="table mb-0">
          <thead><tr><th>Bahan</th><th>Sisa</th></tr></thead>
          <tbody>
          <?php while($s=mysqli_fetch_assoc($stokRendah)): ?>
          <tr>
            <td><?= htmlspecialchars($s['nama_bahan']) ?></td>
            <td><span class="rbadge sb-danger"><?= $s['jumlah'] ?> <?= $s['satuan'] ?></span></td>
          </tr>
          <?php endwhile; ?>
          <?php if(!$stokRendah || mysqli_num_rows($stokRendah)==0): ?>
          <tr><td colspan="2" class="text-center text-muted py-3" style="font-size:13px">Semua stok aman ✓</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../../includes/layout_end.php'; ?>
