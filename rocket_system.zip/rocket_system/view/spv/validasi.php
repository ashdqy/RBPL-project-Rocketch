<?php
require_once __DIR__ . '/../../middleware/role_spv.php';
require_once __DIR__ . '/../../config/database.php';
$pageTitle = 'Validasi Laporan';
$msg = '';

if(isset($_GET['finalize'])) {
    $id = (int)$_GET['finalize'];
    mysqli_query($conn,"UPDATE laporan SET status='FINAL' WHERE id_laporan=$id");
    $msg = 'Laporan berhasil difinalisasi.';
}

$draftList = mysqli_query($conn,"SELECT l.*, u.nama spv FROM laporan l JOIN users u ON l.id_spv=u.id_user WHERE l.status='DRAFT' ORDER BY l.tanggal DESC");
include __DIR__ . '/../../includes/layout_start.php';
?>

<?php if($msg): ?>
<div class="alert sb-success alert-auto d-flex gap-2 align-items-center mb-3" style="border-radius:9px;font-size:13px;padding:10px 14px">
  <i class="fa-solid fa-check-circle"></i><?= htmlspecialchars($msg) ?>
</div>
<?php endif; ?>

<div class="card-box">
  <div class="c-head">
    <h5><i class="fa-solid fa-check-double me-2" style="color:#10b981"></i>Laporan Draft — Menunggu Validasi</h5>
  </div>
  <div class="c-body p-0">
    <table class="table table-hover mb-0">
      <thead><tr><th>Jenis</th><th>Periode</th><th>SPV</th><th>Total Penjualan</th><th>Laba/Rugi</th><th>Dibuat</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php 
      $hasRow = false;
      while($l=mysqli_fetch_assoc($draftList)):
        $hasRow = true;
      ?>
      <tr>
        <td><span class="rbadge sb-info"><?= $l['jenis'] ?></span></td>
        <td><?= htmlspecialchars($l['periode']) ?></td>
        <td><?= htmlspecialchars($l['spv']) ?></td>
        <td>Rp <?= number_format($l['total_penjualan']??0,0,',','.') ?></td>
        <td style="color:<?= ($l['laba_rugi']??0)>=0?'#16a34a':'#dc2626' ?>;font-weight:700">
          Rp <?= number_format($l['laba_rugi']??0,0,',','.') ?></td>
        <td style="font-size:12px;color:#6b7280"><?= date('d/m/Y H:i',strtotime($l['tanggal'])) ?></td>
        <td>
          <a href="?finalize=<?=$l['id_laporan']?>" class="btn btn-sm btn-outline-success" style="font-size:11px;border-radius:6px" onclick="return confirm('Finalisasi laporan ini?')">
            <i class="fa-solid fa-check me-1"></i>Finalisasi
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if(!$hasRow): ?>
      <tr><td colspan="7" class="text-center py-4 text-muted" style="font-size:13px">
        <i class="fa-solid fa-check-circle me-2" style="color:#10b981"></i>Tidak ada laporan draft yang perlu divalidasi
      </td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../../includes/layout_end.php'; ?>
