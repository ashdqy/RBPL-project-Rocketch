<?php
require_once __DIR__ . '/../../../middleware/role_admin.php';
require_once __DIR__ . '/../../../config/database.php';
$pageTitle = 'Backup Database';

$msg = '';
if(isset($_POST['backup'])) {
    // Generate SQL dump info (functional backup requires mysqldump CLI access)
    $tables_res = mysqli_query($conn,"SHOW TABLES");
    $tables = [];
    while($row = mysqli_fetch_row($tables_res)) $tables[] = $row[0];
    
    $output = "-- Rocket Chicken Backup\n-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
    $output .= "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n";
    
    foreach($tables as $table) {
        $output .= "-- Table: $table\n";
        $output .= "DROP TABLE IF EXISTS `$table`;\n";
        $create = mysqli_fetch_row(mysqli_query($conn,"SHOW CREATE TABLE `$table`"));
        $output .= $create[1] . ";\n\n";
        
        $rows = mysqli_query($conn,"SELECT * FROM `$table`");
        while($row = mysqli_fetch_assoc($rows)) {
            $values = array_map(fn($v)=>is_null($v)?'NULL':"'".mysqli_real_escape_string($conn,$v)."'", $row);
            $output .= "INSERT INTO `$table` VALUES(".implode(',',$values).");\n";
        }
        $output .= "\n";
    }
    
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="rocketch_backup_' . date('Ymd_His') . '.sql"');
    echo $output;
    exit;
}

// Get table sizes
$tableInfo = mysqli_query($conn,"
    SELECT table_name, table_rows, 
           ROUND((data_length+index_length)/1024,1) size_kb
    FROM information_schema.tables 
    WHERE table_schema='rocketch'
    ORDER BY table_name
");

include __DIR__ . '/../../../includes/layout_start.php';
?>

<div class="row g-3">
<div class="col-lg-5">
<div class="card-box">
  <div class="c-head">
    <h5><i class="fa-solid fa-database me-2" style="color:#6366f1"></i>Backup Database</h5>
  </div>
  <div class="c-body">
    <div class="text-center py-3">
      <div style="font-size:52px;color:#6366f1;margin-bottom:12px"><i class="fa-solid fa-database"></i></div>
      <p style="font-size:13px;color:#6b7280">Download seluruh data database dalam format SQL. Simpan di tempat yang aman.</p>
      <form method="POST">
        <button type="submit" name="backup" class="btn w-100" style="background:#6366f1;color:#fff;border-radius:9px;font-size:14px;padding:12px">
          <i class="fa-solid fa-download me-2"></i>Download Backup SQL
        </button>
      </form>
      <p class="text-muted mt-2" style="font-size:11px">Terakhir diakses: <?= date('d M Y H:i') ?></p>
    </div>
  </div>
</div>
</div>

<div class="col-lg-7">
<div class="card-box">
  <div class="c-head">
    <h5><i class="fa-solid fa-table me-2" style="color:#10b981"></i>Info Tabel</h5>
  </div>
  <div class="c-body p-0">
    <table class="table table-hover mb-0">
      <thead><tr><th>Tabel</th><th>Jumlah Baris</th><th>Ukuran (KB)</th></tr></thead>
      <tbody>
      <?php while($ti=mysqli_fetch_assoc($tableInfo)): ?>
      <tr>
        <td><code style="font-size:12px"><?= $ti['table_name'] ?></code></td>
        <td><?= number_format($ti['table_rows']) ?></td>
        <td><?= $ti['size_kb'] ?? '< 1' ?></td>
      </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</div>

<?php include __DIR__ . '/../../../includes/layout_end.php'; ?>
