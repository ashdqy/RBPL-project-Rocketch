<?php
require_once __DIR__ . '/../../middleware/role_spv.php';
require_once __DIR__ . '/../../config/database.php';
$pageTitle = 'Generate Laporan';
$msg = '';

if($_SERVER['REQUEST_METHOD']==='POST') {
    $jenis   = $_POST['jenis']??'';
    $periode = trim($_POST['periode']??'');
    $status  = $_POST['finalize']??'' ? 'FINAL' : 'DRAFT';
    
    // Calculate financials
    $dateFilter = '';
    if($jenis === 'HARIAN') {
        $dateFilter = "DATE(tanggal)='$periode'";
    } else {
        $parts = explode('-', $periode);
        if(count($parts)==2) {
            $dateFilter = "YEAR(tanggal)='{$parts[0]}' AND MONTH(tanggal)='{$parts[1]}'";
        }
    }
    
    $totalPenjualan = 0; $totalPengeluaran = 0; $totalReturn = 0;
    if($dateFilter) {
        $res = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total),0) s FROM transaksi WHERE status_pembayaran='PAID' AND $dateFilter"));
        $totalPenjualan = $res['s'];
        $res2 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(COUNT(*)*50000,0) s FROM return_barang WHERE $dateFilter"));
        $totalReturn = $res2['s'];
    }
    $labaRugi = $totalPenjualan - $totalPengeluaran - $totalReturn;
    
    $id_spv = $_SESSION['id_user'];
    $stmt = mysqli_prepare($conn,"INSERT INTO laporan (jenis,periode,id_spv,total_penjualan,total_pengeluaran,total_return,laba_rugi,status) VALUES(?,?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt,'ssidddd s',$jenis,$periode,$id_spv,$totalPenjualan,$totalPengeluaran,$totalReturn,$labaRugi,$status);
    // Fix bind
    $stmt2 = mysqli_prepare($conn,"INSERT INTO laporan (jenis,periode,id_spv,total_penjualan,total_pengeluaran,total_return,laba_rugi,status) VALUES(?,?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt2,'ssidd dds',$jenis,$periode,$id_spv,$totalPenjualan,$totalPengeluaran,$totalReturn,$labaRugi,$status);
    
    // Use direct query
    $j = mysqli_real_escape_string($conn,$jenis);
    $p = mysqli_real_escape_string($conn,$periode);
    $st= mysqli_real_escape_string($conn,$status);
    mysqli_query($conn,"INSERT INTO laporan (jenis,periode,id_spv,total_penjualan,total_pengeluaran,total_return,laba_rugi,status) VALUES('$j','$p',$id_spv,$totalPenjualan,0,$totalReturn,$labaRugi,'$st')");
    $msg = "Laporan berhasil dibuat dengan status $status.";
}

$laporanList = mysqli_query($conn,"SELECT l.*, u.nama spv FROM laporan l JOIN users u ON l.id_spv=u.id_user WHERE l.id_spv='".(int)$_SESSION['id_user']."' ORDER BY l.tanggal DESC");
include __DIR__ . '/../../includes/layout_start.php';
?>

<?php if($msg): ?>
<div class="alert sb-success alert-auto d-flex gap-2 align-items-center mb-3" style="border-radius:9px;font-size:13px;padding:10px 14px">
  <i class="fa-solid fa-check-circle"></i><?= htmlspecialchars($msg) ?>
</div>
<?php endif; ?>

<div class="row g-3">
<div class="col-lg-4">
<div class="card-box">
  <div class="c-head"><h5><i class="fa-solid fa-plus me-2" style="color:#8b5cf6"></i>Buat Laporan Baru</h5></div>
  <div class="c-body">
    <form method="POST">
      <div class="mb-3">
        <label class="form-label" style="font-size:13px;font-weight:600">Jenis Laporan</label>
        <select name="jenis" class="form-select" style="border-radius:8px" required>
          <option value="HARIAN">Harian</option>
          <option value="STOK">Stok</option>
          <option value="KEUANGAN">Keuangan</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label" style="font-size:13px;font-weight:600">Periode</label>
        <input type="text" name="periode" class="form-control" style="border-radius:8px" required placeholder="Contoh: 2026-02-24 atau 2026-02">
        <small class="text-muted" style="font-size:11px">Format harian: YYYY-MM-DD, bulanan: YYYY-MM</small>
      </div>
      <div class="mb-3 d-flex align-items-center gap-2">
        <input type="checkbox" name="finalize" id="finalize" class="form-check-input" style="width:16px;height:16px">
        <label for="finalize" class="form-check-label" style="font-size:13px">Langsung set FINAL</label>
      </div>
      <button type="submit" class="btn w-100" style="background:#8b5cf6;color:#fff;border-radius:8px;font-size:13px">
        <i class="fa-solid fa-file-circle-plus me-1"></i>Generate Laporan
      </button>
    </form>
  </div>
</div>
</div>

<div class="col-lg-8">
<div class="card-box">
  <div class="c-head"><h5><i class="fa-solid fa-list me-2" style="color:#8b5cf6"></i>Laporan Saya</h5></div>
  <div class="c-body p-0">
    <table class="table table-hover mb-0">
      <thead><tr><th>Jenis</th><th>Periode</th><th>Penjualan</th><th>Laba/Rugi</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php while($l=mysqli_fetch_assoc($laporanList)):
        $sc=$l['status']==='FINAL'?'sb-success':'sb-warning';
      ?>
      <tr>
        <td><span class="rbadge sb-info"><?= $l['jenis'] ?></span></td>
        <td><?= htmlspecialchars($l['periode']) ?></td>
        <td>Rp <?= number_format($l['total_penjualan']??0,0,',','.') ?></td>
        <td style="color:<?= ($l['laba_rugi']??0)>=0?'#16a34a':'#dc2626' ?>;font-weight:700">
          Rp <?= number_format($l['laba_rugi']??0,0,',','.') ?></td>
        <td><span class="rbadge <?=$sc?>"><?= $l['status'] ?></span></td>
        <td>
          <?php if($l['status']==='DRAFT'): ?>
          <a href="validasi.php?finalize=<?=$l['id_laporan']?>" class="btn btn-sm btn-outline-success" style="font-size:11px;border-radius:6px" onclick="return confirm('Finalisasi laporan ini?')">Finalisasi</a>
          <?php else: ?>
          <span class="text-muted" style="font-size:12px">Final</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</div>

<?php include __DIR__ . '/../../includes/layout_end.php'; ?>
