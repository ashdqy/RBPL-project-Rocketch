<?php
require_once __DIR__ . '/../../middleware/auth.php';
if($_SESSION['role']!=='KASIR'){header("Location: ../../dashboard.php");exit;}
require_once __DIR__ . '/../../config/database.php';
$pageTitle = 'Buat Transaksi';
$msg = '';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['submit_trx'])) {
    $metode  = $_POST['metode_pembayaran']??'CASH';
    $items   = $_POST['items']??[];
    
    if(empty($items)) {
        $msg = 'ERROR: Tambahkan minimal 1 menu.';
    } else {
        $no_struk = 'TRX-' . date('YmdHis') . '-' . rand(100,999);
        $total = 0;
        
        foreach($items as $item) {
            if(!isset($item['id_menu'])||!isset($item['jumlah'])) continue;
            $menuRow = mysqli_fetch_assoc(mysqli_query($conn,"SELECT harga FROM menu WHERE id_menu=".(int)$item['id_menu']));
            if($menuRow) $total += $menuRow['harga'] * (int)$item['jumlah'];
        }
        
        $id_kasir = (int)$_SESSION['id_user'];
        mysqli_query($conn,"INSERT INTO transaksi (no_struk,id_kasir,total,status_pembayaran,metode_pembayaran) VALUES('$no_struk',$id_kasir,$total,'PAID','$metode')");
        $trxId = mysqli_insert_id($conn);
        
        foreach($items as $item) {
            if(!isset($item['id_menu'])||!isset($item['jumlah'])) continue;
            $mid = (int)$item['id_menu'];
            $qty = (int)$item['jumlah'];
            $menuRow = mysqli_fetch_assoc(mysqli_query($conn,"SELECT harga FROM menu WHERE id_menu=$mid"));
            if($menuRow) {
                $harga   = $menuRow['harga'];
                $subtotal= $harga * $qty;
                mysqli_query($conn,"INSERT INTO detail_transaksi (id_transaksi,id_menu,jumlah,harga,subtotal) VALUES($trxId,$mid,$qty,$harga,$subtotal)");
            }
        }
        
        header("Location: riwayat.php?sukses=".urlencode("Transaksi $no_struk berhasil! Total: Rp ".number_format($total,0,',','.'))); exit;
    }
}

$menuList = mysqli_query($conn,"SELECT * FROM menu WHERE is_active=1 ORDER BY kategori,nama_menu");
$menus = [];
while($m=mysqli_fetch_assoc($menuList)) $menus[] = $m;
$byKategori = [];
foreach($menus as $m) $byKategori[$m['kategori']][] = $m;

include __DIR__ . '/../../includes/layout_start.php';
?>

<?php if($msg): ?>
<div class="alert sb-danger mb-3" style="border-radius:9px;font-size:13px;padding:10px 14px"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<form method="POST" id="trxForm">
<div class="row g-3">
  <!-- Menu Selection -->
  <div class="col-lg-7">
    <div class="card-box">
      <div class="c-head"><h5><i class="fa-solid fa-utensils me-2" style="color:#e63946"></i>Pilih Menu</h5></div>
      <div class="c-body">
        <?php foreach($byKategori as $kat => $items): ?>
        <h6 style="font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:#9ca3af;margin-bottom:8px"><?= htmlspecialchars($kat) ?></h6>
        <div class="row g-2 mb-3">
          <?php foreach($items as $m): ?>
          <div class="col-sm-4">
            <div class="p-2 border rounded" style="border-radius:8px!important;cursor:pointer;transition:.15s" 
                 onclick="addToCart(<?=$m['id_menu']?>,<?= htmlspecialchars(json_encode($m['nama_menu'])) ?>,<?=$m['harga']?>)"
                 onmouseover="this.style.background='#f0fdf4'" onmouseout="this.style.background=''">
              <div style="font-size:12.5px;font-weight:600"><?= htmlspecialchars($m['nama_menu']) ?></div>
              <div style="font-size:11px;color:#10b981;font-weight:700">Rp <?= number_format($m['harga'],0,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
        <?php if(empty($byKategori)): ?>
        <p class="text-muted text-center py-3" style="font-size:13px">Belum ada menu aktif. Tambahkan menu terlebih dahulu.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Cart -->
  <div class="col-lg-5">
    <div class="card-box" style="position:sticky;top:70px">
      <div class="c-head"><h5><i class="fa-solid fa-shopping-cart me-2" style="color:#10b981"></i>Keranjang</h5></div>
      <div class="c-body">
        <div id="cartItems" style="min-height:80px">
          <p class="text-muted text-center" id="emptyMsg" style="font-size:13px;padding:20px 0">Klik menu untuk menambahkan</p>
        </div>
        <hr>
        <div class="d-flex justify-content-between mb-3">
          <strong style="font-size:15px">Total:</strong>
          <strong style="font-size:18px;color:#e63946" id="totalDisplay">Rp 0</strong>
        </div>
        <div class="mb-3">
          <label class="form-label" style="font-size:12px;font-weight:600">Metode Pembayaran</label>
          <select name="metode_pembayaran" class="form-select form-select-sm" style="border-radius:7px">
            <option value="CASH">Cash</option>
            <option value="QRIS">QRIS</option>
            <option value="TRANSFER">Transfer</option>
          </select>
        </div>
        <button type="submit" name="submit_trx" id="btnSubmit" class="btn w-100" 
                style="background:#e63946;color:#fff;border-radius:8px;font-size:14px;padding:11px" disabled>
          <i class="fa-solid fa-check me-2"></i>Proses Transaksi
        </button>
        <div id="hiddenItems"></div>
      </div>
    </div>
  </div>
</div>
</form>

<script>
const cart = {};

function addToCart(id, nama, harga) {
  if (cart[id]) cart[id].jumlah++;
  else cart[id] = { id, nama, harga, jumlah: 1 };
  renderCart();
}

function removeItem(id) {
  delete cart[id];
  renderCart();
}

function changeQty(id, delta) {
  cart[id].jumlah += delta;
  if (cart[id].jumlah <= 0) delete cart[id];
  renderCart();
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const hidden = document.getElementById('hiddenItems');
  const emptyMsg = document.getElementById('emptyMsg');
  const btnSubmit = document.getElementById('btnSubmit');
  
  let total = 0;
  let html = '';
  let hiddenHtml = '';
  let i = 0;
  
  for (const id in cart) {
    const item = cart[id];
    const subtotal = item.harga * item.jumlah;
    total += subtotal;
    html += `<div class="d-flex justify-content-between align-items-center mb-2" style="font-size:13px">
      <div>
        <div style="font-weight:600">${item.nama}</div>
        <div style="color:#6b7280;font-size:11px">Rp ${item.harga.toLocaleString('id-ID')} × ${item.jumlah}</div>
      </div>
      <div class="d-flex align-items-center gap-1">
        <button type="button" onclick="changeQty(${id},-1)" class="btn btn-sm btn-outline-secondary" style="width:24px;height:24px;padding:0;font-size:12px;border-radius:5px">-</button>
        <span style="min-width:20px;text-align:center">${item.jumlah}</span>
        <button type="button" onclick="changeQty(${id},1)" class="btn btn-sm btn-outline-secondary" style="width:24px;height:24px;padding:0;font-size:12px;border-radius:5px">+</button>
        <button type="button" onclick="removeItem(${id})" class="btn btn-sm btn-outline-danger" style="width:24px;height:24px;padding:0;font-size:10px;border-radius:5px">✕</button>
      </div>
    </div>`;
    hiddenHtml += `<input type="hidden" name="items[${i}][id_menu]" value="${id}">
                   <input type="hidden" name="items[${i}][jumlah]" value="${item.jumlah}">`;
    i++;
  }
  
  if (i === 0) {
    container.innerHTML = '<p class="text-muted text-center" id="emptyMsg" style="font-size:13px;padding:20px 0">Klik menu untuk menambahkan</p>';
    btnSubmit.disabled = true;
  } else {
    container.innerHTML = html;
    btnSubmit.disabled = false;
  }
  
  hidden.innerHTML = hiddenHtml;
  document.getElementById('totalDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
}
</script>

<?php include __DIR__ . '/../../includes/layout_end.php'; ?>
